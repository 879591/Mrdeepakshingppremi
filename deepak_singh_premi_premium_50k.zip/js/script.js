const observer = new IntersectionObserver((entries)=>{
  entries.forEach(entry=>{
    if(entry.isIntersecting) entry.target.classList.add("show");
  });
},{threshold:.12});
document.querySelectorAll(".reveal").forEach(el=>observer.observe(el));

const menu=document.querySelector(".menu");
const nav=document.querySelector(".nav");
menu?.addEventListener("click",()=>{
  const open=nav.classList.toggle("open");
  if(open){
    nav.style.display="flex";
    nav.style.position="absolute";
    nav.style.top="82px";
    nav.style.left="0";
    nav.style.right="0";
    nav.style.padding="22px 5%";
    nav.style.background="#090909";
    nav.style.flexDirection="column";
    nav.style.borderBottom="1px solid rgba(255,255,255,.1)";
  }else{
    nav.removeAttribute("style");
  }
});
document.querySelectorAll(".nav a").forEach(a=>a.addEventListener("click",()=>{
  if(window.innerWidth<=900){nav.classList.remove("open");nav.removeAttribute("style")}
}));
